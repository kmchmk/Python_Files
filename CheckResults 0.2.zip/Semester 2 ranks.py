print "This program can be used to check your second semester GPA and the rank!!!"


try:
    def returnGPA(a):
        Letter = ["A+","A","A-","B+","B","B-","C+","C","C-","D","F","I-we","I-ca","","-"]
        GPA = [4.2,4.0,3.7,3.3,3.0,2.7,2.3,2.0,1.5,1.0,0.0,0.0,0.0,0.0,0.0]
        for i in range(len(Letter)):
            if(a==Letter[i]):
                return GPA[i]
        print "Returned nothing"
        return

    def returnTotalGpa(oneLine):
        alist = oneLine.split("\t")
        b = [];
        for x in range(1,10):
            b += [returnGPA(alist[x])]
        return [((3.0 * b[0])+ (2.5 * b[1]) + (3.0 * b[2]) + (2.0 * b[4]) + (2.0 * b[5]) + (2.0 * b[6]) + (1.5 * b[7]) + (3.0 * b[8]))/19,alist[-1]]


    def searchdetails(inp):
        f = open("results","r")
        f.readline()
        for c in range(125):
            try:
                templine = f.readline()
                if(templine[:6]==inp[:6]):
                    index = templine[:6]
                    myresult = returnTotalGpa(templine)
            except:
                break
        f.close()


        f = open("results","r")
        f.readline()
        rank = 1
        for c in range(124):
            templine = f.readline()
            if(returnTotalGpa(templine)[0]>myresult[0]):
                rank+=1
        Name = myresult[1]
        GPA1 = myresult[0]
        return [Name,GPA1,rank,index]

    while(True):
        print "\n\n"
        print "How do you want to search the results?"
        print "1 - with rank\n2 - with index"
        print "3 - Get a full list\n"


        choice = int(input("Enter your choice: "))

        if(choice == 1):
            print "Now you can enter a rank and see who is that..."
            fo = open("results","r")
            fo.readline()
            inp = int(input("Enter a rank: "))
            while(True):
                try:
                    
                    tempinp = fo.readline()[:6]
                    details = searchdetails(tempinp)
                    if(details[2]==inp):
                        print "\nIndex\t= " + details[3]
                        print "Name\t= " + details[0],
                        print "GPA\t= "+str(details[1])

                        

                except:
                    break
            fo.close()
            
        if(choice == 2):
            print "you can check your GPA and rank with your index"
            inp = raw_input("Enter index: ")
            details = searchdetails(inp)
            print "Name\t= " + details[0],
            print "GPA\t= "+str(details[1])
            print "Rank\t= "+str(details[2])

        if(choice == 3):
            print "you can see a full list with GPA and rank"
            for inp in range(125):
                fo = open("results","r")
                fo.readline()
                while(True):
                    try:
                        
                        tempinp = fo.readline()[:6]
                        details = searchdetails(tempinp)
                        if(details[2]==inp):
                            print "\nRank\t= " + str(inp)
                            print "Index\t= " + details[3]
                            print "Name\t= " + details[0],
                            print "GPA\t= "+str(details[1])

                            

                    except:
                        break
                fo.close()
except:
    print "\n\n* First read the instructions.\n* Then do what you are asked to do.\n* Don't act like a fool.\n* As a punishment you will have to restart the program.\n* See you then!"
