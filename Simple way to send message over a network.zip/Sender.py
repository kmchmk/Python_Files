import os.path

##Enter receiver's pc name here
print "Go to My computer properties  and check the computer name.....\n"
nameOfReceiverPC = raw_input("Enter receiver's PC Name: ")

raw_input("Now run the Receiver and press enter here....")
print "\n"





##Do not modify
name = os.path.join("//"+nameOfReceiverPC+"/Users/Public","sms")
while(True):
        f = open(name,"w")
        text = raw_input("Enter message: ")
        f.write(text)
        f.close();
