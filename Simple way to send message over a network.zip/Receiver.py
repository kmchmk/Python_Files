import os.path
name = os.path.join("C:/Users/Public","sms")
text = ""

print "Go to \"Network and Sharing Center -> Advanced Sharing Settings\"\nTurn on \"network sharing\" and turn off \"password protected sharing\"\n\nNow send me a message...\n"

while(True):
    f = open(name,"r")
    read = f.read()
    if read != text:
        print read
    text=read
    f.close();
