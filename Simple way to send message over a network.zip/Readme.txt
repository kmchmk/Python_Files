Need Python 2.7 installed on both laptops
Go to "Network and Sharing Center -> Advanced Sharing Settings"
Turn on all "network sharings" and turn off "password protected sharing"



*	Connect two laptops via ethernet cable or wi-fi.

Or

*	Just create a wifi hotspot using a phone and connect the two laptops to that hotspot.